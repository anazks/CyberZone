# NodeJS-job-portal

A simple node js job portal using nodejs Express ,Mongoose

download or clone the code 
npm i //for installing the dependencies
npm start //for running production
npm run dev //for running development
