**VISIT WEBSITE:**
http://earthquake-predictor-india.herokuapp.com/

**EXPLANATION VIDEO:** https://youtu.be/pTkrJRw96XY

**Android App:** https://bit.ly/Earthquake-Predictor-India

![22](https://user-images.githubusercontent.com/86513644/132936926-7cd60a83-24e5-441f-b8fb-946dcd8d8bc0.PNG)

**Social Handles: Get connected on Social Medias:** https://shivanshvasusocialhandles.000webhostapp.com/
        
**FOR ANY INFORMATION OR HELP MAIL AT:** Drop mail at: shivanshphone@gmail.com
