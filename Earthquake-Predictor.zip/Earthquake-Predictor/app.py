#Code By-Shivansh Vasu


from flask import Flask,request, url_for, redirect, render_template
import pickle
import numpy as np
import pickle
import joblib

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
import pickle
from sklearn import metrics
from sklearn.ensemble import RandomForestClassifier
app = Flask(__name__)

# model = pickle.load(open('model.pkl','rb'))
# data = joblib.dump(model, 'model.pkl')

# arr = np.array([[float(data1), float(data2), float(data3)]])


@app.route('/', methods=["POST","GET"])
def home():
    data = pd.read_csv("dataset.csv")

    data = np.array(data)
    print(data)
    X = data[:, 0:-1]
    y = data[:, -1]
    y = y.astype('int')
    X = X.astype('int')

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

    #  print(X_train,y_train)
    rfc = RandomForestClassifier()
    rfc.fit(X_train, y_train)
    # y_pred = rfc.predict(X_test)
    y_pred = rfc.predict(X_test)
    print(y_pred)
    print(metrics.accuracy_score(y_test, y_pred))

    if "submit" in request.form:
        data1 = int(float(request.form['a']))
        data2 = int(float(request.form['b']))
        data3 = int(float(request.form['c']))
        print(data1,data2,data3)
        arr = np.array([[data1, data2, data3]])

        model = rfc.predict(arr)
        print(model)
        if model[0] < 4:
            val = "Low Chance"
        elif model[0] >= 4 and model[0] < 6 :
            val = "Moderate chance"
        elif model[0] >= 6 and model[0] < 8 :
            val = "Chance For earth quk"
        elif model[0] > 8 :
            val = "High Chance for erth quick"

        return render_template('predict.html',model = val)

    return render_template('index.html')


@app.route('/home')
def home2():
    return render_template('homepage.html')

    
@app.route('/error')
def error():
    return render_template('error.html')


@app.route('/aboutproject')
def aboutproject():
    return render_template('aboutproject.html')



@app.route('/review')
def review():
    return render_template('review.html')


@app.route('/sourcecode')
def sourcecode():
    return render_template('sourcecode.html')

@app.route('/creator')
def creator():
    return render_template('creator.html')





@app.route('/prediction' , methods=['POST','GET'])
def prediction():
    data1 = int(float(request.form['a']))
    data2 = int(float(request.form['b']))
    data3 = int(float(request.form['c']))
    print(data1,data2,data3)
    arr = np.array([[data1, data2, data3]])
    output= model.predict(arr)

    return render_template("prediction.html")


    # def to_str(var):
    #     return str(list(np.reshape(np.asarray(var), (1, np.size(var)))[0]))[1:-1]
     
   
    # return render_template('prediction.html')

    # if (output<4):
    #     return render_template('prediction.html',p=to_str(output), q=' No ')
    # elif (output>4 & output<6):
    #     return render_template('prediction.html',p=to_str(output), q= ' Low ')
    # elif (output>6 & output<8):
    #     return render_template('prediction.html',p=to_str(output), q=' Moderate ')
    # elif (output>8 & output<9):
    #     return render_template('prediction.html',p=to_str(output), q=' High ')
    # elif (output>9):
    #     return render_template('prediction.html',p=to_str(output), q=' Very Hogh ')
    
    # else :
    #     return render_template('prediction.html',p=' N.A.', q= ' Undefined ')


if __name__ == "__main__":
    app.run(debug=True)






#Code By-Shivansh Vasu








